"""Midea AC message."""

import logging
from collections.abc import Callable, Mapping
from enum import IntEnum
from types import MappingProxyType

from midealan.const import MAX_BYTE_VALUE, DeviceType
from midealan.crc8 import calculate
from midealan.message import (
    ListTypes,
    MessageBody,
    MessageRequest,
    MessageResponse,
    MessageType,
    NewProtocolMessageBody,
)

_LOGGER = logging.getLogger(__name__)

A1_MIN_BODY_LENGTH = 18

BB_AC_MODES = [0, 3, 1, 2, 4, 5]
BB_MIN_BODY_LENGTH = 21
BB_FRESH_AIR_SWITCH_INDEX = 45
BB_FRESH_AIR_INTAKE_STATUS_MASK = 0x01
BB_FRESH_AIR_EXHAUST_STATUS_MASK = 0x02
BB_FRESH_AIR_INTAKE_SPEED_INDEX = 46
BB_FRESH_AIR_EXHAUST_SPEED_INDEX = 47
BB_COMPRESSOR_TARGET_FREQUENCY_INDEX = 10
BB_COMPRESSOR_FREQUENCY_INDEX = 11
BB_BASIC_FAN_SPEED_INDEX = 7
BB_INDOOR_TEMPERATURE_HIGH_INDEX = 8
BB_INDOOR_HUMIDITY_INDEX = 30
BB_SN8_FLAG_INDEX = 80
BB_OUTDOOR_TEMPERATURE_HIGH_INDEX = 6
CONFORT_MODE_MIN_LENGTH = 16
CONFORT_MODE_MIN_LENGTH2 = 23
SMART_DRY_MIN_LENGTH = 20
SWING_LR_MIN_LENGTH = 21
FRESH_AIR_C0_MIN_LENGTH = 29
ECO_MODE_MIN_SUBPROTOCOL_LENGTH = 27
FRESH_AIR_LENGTH = 2
FROST_PROTECT_MIN_LENGTH = 22
INDIRECT_WIND_VALUE = 0x02
MAX_MSG_SERIAL_NUM = 254
OUT_SILENT_VALUE = 0x03
POWER_SAVING_VALUE = 0x08
SCREEN_DISPLAY_BYTE_CHECK = 0x07
SUB_PROTOCOL_BODY_TEMP_CHECK = 0x80
TEMP_DECIMAL_MIN_BODY_LENGTH = 20
C0_DEFAULT_TEMPERATURE_OFFSET = 50
C0_DEFAULT_INVALID_OUTDOOR_TEMPERATURE_VALUES: frozenset[int] = frozenset()
TIMER_MIN_SUBPROTOCOL_LENGTH = 27
XBB_SN8_BYTE_FLAG = 0x31
XC1_SUBBODY_TYPE_40 = 0x40
XC1_SUBBODY_TYPE_41 = 0x41
XC1_SUBBODY_TYPE_42 = 0x42
XC1_SUBBODY_TYPE_44 = 0x44
XC1_SUBBODY_TYPE_45 = 0x45
XC1_SUBBODY_TYPE_47 = 0x47
XC1_SUBBODY_TYPE_INDEX = 3
XC1_HUMIDITY_INDEX = 4
XC1_CONSUMPTION_MIN_LENGTH = 19
XC1_OPERATING_TIME_MIN_LENGTH = 19

# Group data query: the third payload byte selects the group, 0x40 | group number.
XC1_GROUP_QUERY_BASE = 0x40
# Minimum body length required to parse each group data response.
XC1_GROUP_ONE_MIN_LENGTH = 15
XC1_GROUP_TWO_MIN_LENGTH = 9
XC1_GROUP_SEVEN_MIN_LENGTH = 12
# Refrigerant circuit temperatures are reported as half degrees with an offset:
# T1/T2 (indoor ambient / indoor coil) use 30, T3/T4 (outdoor coil / ambient) use 50.
XC1_TEMP_INDOOR_OFFSET = 30
XC1_TEMP_OUTDOOR_OFFSET = 50
XC1_TEMP_DIVISOR = 2
# Indoor fan speed is reported in units of 8 RPM.
XC1_FAN_SPEED_FACTOR = 8
# Bit 4 of group 2 byte 8 indicates the condensate water pump is running.
XC1_WATER_PUMP_MASK = 0x10

BB_FRESH_AIR_CONTROL_BODY_LENGTH = 96
BB_FRESH_AIR_CONTROL_CURSOR = 15
BB_FRESH_AIR_INTAKE_SWITCH_MASK = 0x04
BB_FRESH_AIR_EXHAUST_SWITCH_MASK = 0x08
BB_FRESH_AIR_INTAKE_CONTROL_SPEED_INDEX = 55
BB_FRESH_AIR_EXHAUST_CONTROL_SPEED_INDEX = 56
BB_FRESH_AIR_SPEED_FLAG = 0x80

# Model 22013279 reports temperatures in this new-protocol tag because its
# standard C0 temperature fields are stale.
NEW_PROTOCOL_TEMPERATURE_TAG = 0x7E
NEW_PROTOCOL_TEMPERATURE_MIN_LENGTH = 41
NEW_PROTOCOL_SETPOINT_OFFSET = 11.5
NEW_PROTOCOL_SETPOINT_MASK = 0x3F
NEW_PROTOCOL_SETPOINT_HALF_DEGREE_BIT = 0x40
NEW_PROTOCOL_MIN_VALID_TEMPERATURE = 10
NEW_PROTOCOL_MAX_VALID_TEMPERATURE = 40
NEW_PROTOCOL_LEGACY_SETPOINT_BYTE = 3
NEW_PROTOCOL_INDOOR_TEMPERATURE_BYTE = 40
NEW_PROTOCOL_INDOOR_TEMPERATURE_DECIMAL_BYTE = 41

# Model-specific optional property payloads used by 220F4047.
# Keep the values raw unless their wire meaning is unambiguous.
MODE_POWER_TEMPERATURE_SCALE = 2
WIND_STRAIGHT_VALUE = 0x01
YB_WIND_AVOID_VALUE = 0x02
LIGHT_SENSITIVE_ENABLED_VALUE = 0x03
FILTER_LEVEL_INDEX = 1
FILTER_VALUE_INDEX = 10
FILTER_MIN_PAYLOAD_LENGTH = FILTER_VALUE_INDEX + 1

# Model 220F4047 / subtype 8 uses the property layout published by Midea's
# subtype-8 Lua adapter. These swing tags are deliberately separate from the
# generic fixed-angle tags (0x0009/0x000A), whose meanings overlap on other
# firmware.
MODEL_220F4047_SWING_UD_TAG = 0x0008
MODEL_220F4047_SWING_LR_TAG = 0x0009
MODEL_220F4047_WIND_DEFLECTOR_TAG = 0x000A
MODEL_220F4047_ECO_TAG = 0x000D
MODEL_220F4047_DRY_TAG = 0x0010
MODEL_220F4047_COOL_HOT_SENSE_TAG = 0x0021
MODEL_220F4047_POWER_SAVING_TAG = 0x0050
MODEL_220F4047_SWING_ENABLED_VALUE = 0x03
MODEL_220F4047_UNCHANGED_DEFLECTOR_VALUE = 0xFF
MODEL_220F4047_DEFLECTOR_PAYLOAD_LENGTH = 2
MODEL_220F4047_CORE_PROPERTY_TAGS = (
    MODEL_220F4047_SWING_UD_TAG,
    MODEL_220F4047_SWING_LR_TAG,
    MODEL_220F4047_WIND_DEFLECTOR_TAG,
    MODEL_220F4047_ECO_TAG,
    MODEL_220F4047_DRY_TAG,
    MODEL_220F4047_COOL_HOT_SENSE_TAG,
    MODEL_220F4047_POWER_SAVING_TAG,
)

# B5 capability value semantics (reverse-engineered; see _parse_capabilities).
# The raw byte of each capability is not a 0/1 flag; each has its own value set.
B5_HEAT_MODE_VALUES = frozenset({1, 2, 4, 6, 7, 9, 10, 11, 12, 13})
B5_NO_COOL_MODE_VALUES = frozenset({2, 10, 12})
B5_DRY_MODE_VALUES = frozenset({0, 1, 5, 6, 9, 11, 13})
B5_AUTO_MODE_VALUES = frozenset({0, 1, 2, 7, 8, 9, 13})
B5_SWING_HORIZONTAL_VALUES = frozenset({1, 3})
B5_LOW_VALUE_MAX = 2  # value < 2 -> vertical swing / cool turbo available
B5_FAN_LOW_HIGH_VALUES = frozenset({3, 4, 5, 6, 7, 9})
B5_FAN_MEDIUM_VALUES = frozenset({5, 6, 7})
B5_FAN_AUTO_VALUES = frozenset({4, 5, 6, 9})
B5_FAN_SILENT_VALUES = frozenset({6, 9})
B5_FAN_CUSTOM_VALUE = 1
B5_ECO_VALUES = frozenset({1, 2})
B5_ANION_ON_VALUE = 1
B5_TURBO_HEAT_VALUES = frozenset({1, 3})
B5_DISPLAY_VALUES = frozenset({1, 2, 100})
B5_ELECTRICITY_UNSUPPORTED_VALUE = 0  # 0 = unsupported; nonzero = rate level count


class PowerFormats(IntEnum):
    """AC Power/Energy analysis formats."""

    # unless stated, consumption / energy is 0.01 kWh, and power in 0.1 W resolution
    BCD = 1
    BINARY = 2  # binary with energy in 0.1 kWh resolution
    MIXED = 3  # mixed/INT (byte = 0-99)
    BINARY1 = 12  # binary
    BCD_ENERGY_BINARY_POWER = 101


class NewProtocolTags(IntEnum):
    """New protocol tags in query and response."""

    mode_power = 0x0001
    wind_ud_angle = 0x0009
    wind_lr_angle = 0x000A
    comfort_sleep = 0x0011
    indoor_humidity = 0x0015  # queryType == "indoor_humidity"
    screen_display = 0x0017
    breezeless = 0x0018  # queryType == "fn_no_wind_sense"
    prompt_tone = 0x001A  # buzzerValue
    voice_control = 0x0020
    cool_hot_sense = 0x0021
    volume_control = 0x0024
    security = 0x0029
    nobody_energy_save = 0x0030
    intelligent_control = 0x0031
    wind_straight = 0x0032
    wind_avoid = 0x0033
    intelligent_wind = 0x0034
    # Live self-clean status. Reported in B0 (set echo) and B1 (query) bodies.
    # The same tag in a B5 capability body only advertises support, not state.
    self_clean = 0x0039
    child_prevent_cold_wind = 0x003A
    error_code_query = 0x003F
    mode_query = 0x0041
    indirect_wind = 0x0042  # prevent_straight_wind
    gentle_wind_sense = 0x0043
    face_register = 0x0044
    high_temperature_monitor = 0x0047
    rate_select = 0x0048
    prevent_super_cool = 0x0049
    water_washing = 0x004A
    fresh_air_2 = 0x004B  # queryType == "fresh_air"
    extreme_wind = 0x004C
    even_wind = 0x004E
    single_tuyere = 0x004F
    water_pump = 0x0050
    parent_control = 0x0051
    prevent_straight_wind_lr = 0x0058
    wind_around = 0x0059
    degerming = 0x005A
    light = 0x005B
    child_lock = 0x005C
    self_remove_odor_phase = 0x005D
    high_temp_remove_odor_alone = 0x005E
    ozone = 0x005F
    wind_top = 0x0061
    soft_warm = 0x0063
    jet_cool = 0x0067
    rewarming_dry = 0x0068
    arom = 0x0069
    # AC outdoor silent mode (PortaSplit)
    out_silent = 0x00CD
    ieco_switch = 0x00E3
    nobody_energy_save_tag = 0x00FA
    pre_cool_hot = 0x0201
    light_sensitive = 0x0208
    pm25_value = 0x020B
    b5_wind_speed = 0x0210
    b5_eco = 0x0212
    b5_8_heat = 0x0213
    # b5 device
    b5_mode = 0x0214
    b5_wind_swing = 0x0215
    b5_electricity = 0x0216
    b5_filter_remind = 0x0217
    b5_ptc = 0x0219
    b5_strong_wind = 0x021A
    little_angel = 0x021B
    b5_anion = 0x021E
    b5_humidity = 0x021F
    b5_filter_check = 0x0221
    b5_fahrenheit = 0x0222
    b5_screen_display = 0x0224
    b5_temperature = 0x0225
    auto_prevent_straight_wind = 0x0226
    remote_control_lock = 0x0227  # power_lock?
    operating_time = 0x0228
    ptc_lock = 0x0229
    offline_operating_time = 0x022B
    buzzer_all = 0x022C  # b5_sound
    twins_machine = 0x0232
    fresh_air_1 = 0x0233
    body_check = 0x0234
    fresh_air_parm = 0x0250
    filter_level = 0x0409


class MessageACBase(MessageRequest):
    """AC message base."""

    _message_serial = 0

    def __init__(
        self,
        protocol_version: int,
        message_type: MessageType,
        body_type: ListTypes,
    ) -> None:
        """Initialize AC message base."""
        super().__init__(
            device_type=DeviceType.AC,
            protocol_version=protocol_version,
            message_type=message_type,
            body_type=body_type,
        )
        MessageACBase._message_serial += 1
        if MessageACBase._message_serial >= MAX_MSG_SERIAL_NUM:
            MessageACBase._message_serial = 1
        self._message_id = MessageACBase._message_serial

    @property
    def _body(self) -> bytearray:
        raise NotImplementedError

    @property
    def body(self) -> bytearray:
        """AC message base body."""
        body = bytearray([self.body_type]) + self._body + bytearray([self._message_id])
        body.append(calculate(body))
        return body


class MessageA0Query(MessageACBase):
    """AC message query(queryType == "a0_query")."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.A0,
        )

    @property
    def _body(self) -> bytearray:
        """Head 0x41 + query_body + _message_id + crc."""
        query_body = bytearray(1)
        query_body[0] = 0xA7
        return query_body


class MessageA0LongQuery(MessageACBase):
    """AC message query(queryType == "a0_query_long")."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.A0,
        )

    @property
    def _body(self) -> bytearray:
        """Head 0x41 + query_body + _message_id + crc."""
        return bytearray(19)


class MessageQuery(MessageACBase):
    """AC message query(queryType == nil)."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.X41,
        )

    @property
    def _body(self) -> bytearray:
        """Head 0x41 + query_body + _message_id + crc."""
        query_body = bytearray(19)
        query_body[0] = 0x81
        query_body[2] = 0xFF
        return query_body


class CapabilitiesQuery(MessageACBase):
    """AC message capabilities query(queryType == "all_first_frame")."""

    def __init__(
        self,
        protocol_version: int,
        additional_capabilities: bool = False,
    ) -> None:
        """Initialize AC message capabilities query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.B5,
        )
        self._additional_capabilities = additional_capabilities

    @property
    def _body(self) -> bytearray:
        if self._additional_capabilities:
            return bytearray([0x01, 0x01, 0x01])
        return bytearray([0x01, 0x00])


class CapabilitiesAdditionalQuery(CapabilitiesQuery):
    """AC message capabilities additional query(queryType == "all_second_frame")."""

    def __init__(
        self,
        protocol_version: int,
    ) -> None:
        """Initialize AC message capabilities additional query."""
        super().__init__(
            protocol_version=protocol_version,
            additional_capabilities=True,  # Always set to True for this class
        )


class GroupDataQuery(MessageACBase):
    """AC message group data query(queryType == "group_data_<group>")."""

    _group = 0

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message group data query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.X41,
        )

    @property
    def _body(self) -> bytearray:
        return bytearray(
            [0x21, 0x01, XC1_GROUP_QUERY_BASE | self._group, 0x00, 0x01],
        )

    @property
    def body(self) -> bytearray:
        """AC message group data query body."""
        body = bytearray([self.body_type]) + self._body
        body.append(calculate(body))
        return body


class GroupZeroQuery(GroupDataQuery):
    """AC message power query(queryType == "group_data_zero")."""

    _group = 0


class GroupOneQuery(GroupDataQuery):
    """AC message compressor query(queryType == "group_data_one")."""

    _group = 1


class GroupTwoQuery(GroupDataQuery):
    """AC message indoor fan query(queryType == "group_data_two")."""

    _group = 2


class PowerQuery(GroupDataQuery):
    """AC message power query(queryType == "group_data_four")."""

    _group = 4


class HumidityQuery(GroupDataQuery):
    """AC message query indoor humidity(queryType == "group_data_five")."""

    _group = 5


class GroupSevenQuery(GroupDataQuery):
    """AC message compressor power query(queryType == "group_data_seven")."""

    _group = 7


class ToggleDisplay(MessageACBase):
    """AC message toggle display."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message toggle display."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.X41,
        )
        self.prompt_tone = False

    @property
    def _body(self) -> bytearray:
        prompt_tone = 0x40 if self.prompt_tone else 0
        return bytearray(
            [
                0x02 | prompt_tone,
                0x00,
                0xFF,
                0x02,
                0x00,
                0x02,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
            ],
        )


class NewProtocolQuery(MessageACBase):
    """AC message new protocol query."""

    _query_params: tuple[int, ...] = (
        NewProtocolTags.indirect_wind,
        NewProtocolTags.breezeless,
        NewProtocolTags.indoor_humidity,
        NewProtocolTags.screen_display,
        NewProtocolTags.fresh_air_1,
        NewProtocolTags.fresh_air_2,
        NewProtocolTags.wind_lr_angle,
        NewProtocolTags.wind_ud_angle,
        NewProtocolTags.out_silent,
        NewProtocolTags.buzzer_all,
        NewProtocolTags.error_code_query,
    )

    def __init__(
        self,
        protocol_version: int,
        *,
        supports_rate_select: bool = False,
        supports_220f4047_core_properties: bool = False,
    ) -> None:
        """Initialize AC message new protocol query.

        `supports_rate_select` gates the rate_select (0x0048) query param on
        the device having advertised it via the B5 b5_electricity capability
        (tag 0x0216). Devices that don't report it never answer the query, so
        it's left out until support is confirmed.
        """
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            body_type=ListTypes.B1,
        )
        self._supports_rate_select = supports_rate_select
        self._supports_220f4047_core_properties = supports_220f4047_core_properties

    @property
    def _body(self) -> bytearray:

        params: list[int] = list(self._query_params)
        if self._supports_220f4047_core_properties:
            # 0x0009 and 0x000A are fixed-angle properties on the generic
            # protocol, but subtype 8 uses 0x0009 for horizontal swing and
            # 0x000A for a two-byte fixed-direction pair. Avoid asking for the
            # generic pair, then request the exact-model boolean controls.
            params = [
                param
                for param in params
                if param
                not in {
                    NewProtocolTags.wind_lr_angle,
                    NewProtocolTags.wind_ud_angle,
                }
            ]
            params.extend(MODEL_220F4047_CORE_PROPERTY_TAGS)
        if self._supports_rate_select:
            params.append(NewProtocolTags.rate_select)

        _body = bytearray([len(params)])
        for param in params:
            _body.extend([param & 0xFF, param >> 8])
        return _body


class NewProtocolSelfCleanQuery(NewProtocolQuery):
    """AC message new protocol self-clean query.

    A device answers with an empty parameter list when a query carries a tag it
    does not support, which suppresses every other tag in the same request. The
    self-clean state is therefore asked for as an independent status group.
    """

    _query_params = (NewProtocolTags.self_clean,)


class NewProtocolComfortSleepQuery(NewProtocolQuery):
    """Query the comfort-sleep state independently."""

    _query_params = (NewProtocolTags.comfort_sleep,)


class NewProtocolWindStraightQuery(NewProtocolQuery):
    """Query the wind-toward-person state independently."""

    _query_params = (NewProtocolTags.wind_straight,)


class NewProtocolWindAvoidQuery(NewProtocolQuery):
    """Query the wind-away-from-person state independently."""

    _query_params = (NewProtocolTags.wind_avoid,)


class NewProtocolNobodyEnergySaveQuery(NewProtocolQuery):
    """Query the legacy no-person energy-saving state independently."""

    _query_params = (NewProtocolTags.nobody_energy_save,)


class NewProtocolNobodyEnergySaveTagQuery(NewProtocolQuery):
    """Query the newer no-person energy-saving state independently."""

    _query_params = (NewProtocolTags.nobody_energy_save_tag,)


class NewProtocolLightSensitiveQuery(NewProtocolQuery):
    """Query the smart light-sensing value independently."""

    _query_params = (NewProtocolTags.light_sensitive,)


class NewProtocolFilterQuery(NewProtocolQuery):
    """Query the filter level and cleanliness value independently."""

    _query_params = (NewProtocolTags.filter_level,)


class MessageSubProtocol(MessageACBase):
    """AC message sub protocol."""

    def __init__(
        self,
        protocol_version: int,
        message_type: MessageType,
        subprotocol_query_type: int,
    ) -> None:
        """Initialize AC message sub protocol."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=message_type,
            body_type=ListTypes.AA,
        )
        self._subprotocol_query_type = subprotocol_query_type

    @property
    def _subprotocol_body(self) -> bytes | bytearray:
        return bytes([])

    @property
    def body(self) -> bytearray:
        """AC message sub protocol body."""
        body = bytearray([self.body_type]) + self._body
        body.append(calculate(body))
        body.append(self.checksum(body))
        return body

    @property
    def _body(self) -> bytearray:
        _subprotocol_body = self._subprotocol_body
        _body = bytearray(
            [
                6 + 2 + len(_subprotocol_body),
                0x00,
                0xFF,
                0xFF,
                self._subprotocol_query_type,
            ],
        )
        _body.extend(_subprotocol_body)
        return _body


class SubProtocolQuery(MessageSubProtocol):
    """AC message sub protocol query."""

    def __init__(
        self,
        protocol_version: int,
        subprotocol_query_type: int,
    ) -> None:
        """Initialize AC message sub protocol query."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.query,
            subprotocol_query_type=subprotocol_query_type,
        )


class SubProtocolQuery10(SubProtocolQuery):
    """AC sub protocol indoor status query."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize the indoor status query."""
        super().__init__(protocol_version, ListTypes.X10)


class SubProtocolQuery11(SubProtocolQuery):
    """AC sub protocol basic status query."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize the basic status query."""
        super().__init__(protocol_version, ListTypes.X11)


class SubProtocolQuery30(SubProtocolQuery):
    """AC sub protocol outdoor status query."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize the outdoor status query."""
        super().__init__(protocol_version, ListTypes.X30)


class MessageSubProtocolSet(MessageSubProtocol):
    """AC message sub protocol set."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message sub protocol set."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.set,
            subprotocol_query_type=0x20,
        )
        self.power = False
        self.mode = 0
        self.target_temperature = 20.0
        self.fan_speed = 102
        self.boost_mode = False
        self.aux_heating = False
        self.dry = False
        self.eco_mode = False
        self.sleep_mode = False
        self.sn8_flag = False
        self.timer = False
        self.prompt_tone = False

    @property
    def _subprotocol_body(self) -> bytearray:
        power = 0x01 if self.power else 0
        dry = 0x10 if self.power and self.dry else 0
        boost_mode = 0x20 if self.boost_mode else 0
        aux_heating = 0x40 if self.aux_heating else 0x80
        sleep_mode = 0x80 if self.sleep_mode else 0
        try:
            mode = 0 if self.mode == 0 else BB_AC_MODES[self.mode] - 1
        except IndexError:
            mode = 2  # set Auto if invalid mode
        target_temperature = int(self.target_temperature * 2 + 30)
        water_model_temperature_set = int((self.target_temperature - 1) * 2 + 50)
        fan_speed = int(self.fan_speed)
        eco = 0x40 if self.eco_mode else 0

        prompt_tone = 0x01 if self.prompt_tone else 0
        timer = 0x04 if (self.sn8_flag and self.timer) else 0
        return bytearray(
            [
                0x02 | boost_mode | power | dry,
                aux_heating,
                sleep_mode,
                0x00,
                0x00,
                mode,
                target_temperature,
                fan_speed,
                0x32,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x01,
                0x01,
                0x00,
                0x01,
                water_model_temperature_set,
                prompt_tone,
                target_temperature,
                0x32,
                0x66,
                0x00,
                eco | timer,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x08,
            ],
        )


class SubProtocolFreshAirSet(MessageSubProtocol):
    """AC BB C0/02 single-control fresh-air command."""

    def __init__(
        self,
        protocol_version: int,
        power: bool,
        speed: int,
        *,
        exhaust: bool = False,
    ) -> None:
        """Initialize a fresh-air intake or exhaust command."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.set,
            subprotocol_query_type=ListTypes.C0,
        )
        self.power = power
        self.speed = max(1, min(speed, 100))
        self.exhaust = exhaust

    @property
    def _subprotocol_body(self) -> bytearray:
        body = bytearray(BB_FRESH_AIR_CONTROL_BODY_LENGTH)
        # BB fresh-air controls are sparse C0/02 payloads. The switch bytes are
        # relative to the control cursor; speed bytes are offsets in that block.
        body[1] = 0x01
        body[2] = 0x01
        body[11] = 0x01
        body[12] = ListTypes.C0
        body[13] = 0x02
        body[14] = 0x54
        switch_mask = (
            BB_FRESH_AIR_EXHAUST_SWITCH_MASK
            if self.exhaust
            else BB_FRESH_AIR_INTAKE_SWITCH_MASK
        )
        speed_index = (
            BB_FRESH_AIR_EXHAUST_CONTROL_SPEED_INDEX
            if self.exhaust
            else BB_FRESH_AIR_INTAKE_CONTROL_SPEED_INDEX
        )
        body[BB_FRESH_AIR_CONTROL_CURSOR + 6] = switch_mask
        body[BB_FRESH_AIR_CONTROL_CURSOR + 7] = switch_mask if self.power else 0
        body[BB_FRESH_AIR_CONTROL_CURSOR + speed_index] = (
            BB_FRESH_AIR_SPEED_FLAG | self.speed
        )
        body[-1] = (-sum(body[12:-1])) & MAX_BYTE_VALUE
        return body


class MessageSet(MessageACBase):
    """AC message general set."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message general set."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.set,
            body_type=ListTypes.X40,
        )
        self.power = False
        self.prompt_tone = True
        self.mode = 0
        self.target_temperature = 20.0
        self.fan_speed = 102
        self.swing_vertical = False
        self.swing_horizontal = False
        self.boost_mode = False
        self.power_saving = False
        self.smart_eye = False
        self.dry = False
        self.aux_heating = False
        self.eco_mode = False
        self.temp_fahrenheit = False
        self.sleep_mode = False
        self.natural_wind = False
        self.frost_protect = False
        self.comfort_mode = False
        self.anion = False

    @property
    def _body(self) -> bytearray:
        # Byte1, Power, prompt_tone
        power = 0x01 if self.power else 0
        prompt_tone = 0x40 if self.prompt_tone else 0
        # Byte2, mode target_temperature
        mode = (self.mode << 5) & 0xE0
        target_temperature = (int(self.target_temperature) & 0xF) | (
            0x10 if round(self.target_temperature * 2) % 2 != 0 else 0
        )
        # Byte 3, fan_speed
        fan_speed = int(self.fan_speed) & 0x7F
        # Byte 7, swing_mode
        swing_mode = (
            0x30
            | (0x0C if self.swing_vertical else 0)
            | (0x03 if self.swing_horizontal else 0)
        )
        # Byte 8, turbo, power saving
        boost_mode = 0x20 if self.boost_mode else 0
        power_saving = POWER_SAVING_VALUE if self.power_saving else 0
        # Byte 9 aux_heating eco_mode
        smart_eye = 0x01 if self.smart_eye else 0
        dry = 0x04 if self.dry else 0
        aux_heating = 0x08 if self.aux_heating else 0
        eco_mode = 0x80 if self.eco_mode else 0
        anion = 0x20 if self.anion else 0
        # Byte 10 temp_fahrenheit
        temp_fahrenheit = 0x04 if self.temp_fahrenheit else 0
        sleep_mode = 0x01 if self.sleep_mode else 0
        boost_mode_1 = 0x02 if self.boost_mode else 0
        # Byte 17 natural_wind
        natural_wind = 0x40 if self.natural_wind else 0
        # Byte 21 frost_protect
        frost_protect = 0x80 if self.frost_protect else 0
        # Byte 22 comfort_mode
        comfort_mode = 0x01 if self.comfort_mode else 0

        return bytearray(
            [
                power | prompt_tone,
                mode | target_temperature,
                fan_speed,
                0x00,
                0x00,
                0x00,
                swing_mode,
                boost_mode | power_saving,
                smart_eye | dry | aux_heating | eco_mode | anion,
                temp_fahrenheit | sleep_mode | boost_mode_1,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                0x00,
                natural_wind,
                0x00,
                0x00,
                0x00,
                frost_protect,
                comfort_mode,
            ],
        )


class NewProtocolSet(MessageACBase):
    """AC message new protocol set."""

    def __init__(self, protocol_version: int) -> None:
        """Initialize AC message new protocol set."""
        super().__init__(
            protocol_version=protocol_version,
            message_type=MessageType.set,
            body_type=ListTypes.B0,
        )
        self.indirect_wind: bytes | None = None
        self.prompt_tone: bytes | None = None
        self.breezeless: bytes | None = None
        self.mode_power: tuple[bool, int, float, int] | None = None
        self.swing_vertical: bool | None = None
        self.swing_horizontal: bool | None = None
        self.wind_deflector_ud: int | None = None
        self.wind_deflector_lr: int | None = None
        self.eco_mode: bool | None = None
        self.dry: bool | None = None
        self.cool_hot_sense: bool | None = None
        self.power_saving: bool | None = None
        self.wind_straight: bool | None = None
        self.wind_avoid: bool | None = None
        self.light_sensitive: int | None = None
        self.screen_display_alternate: bytes | None = None
        self.fresh_air_1: bytes | None = None
        self.fresh_air_2: bytes | None = None
        self.wind_lr_angle: bytes | None = None
        self.wind_ud_angle: bytes | None = None
        self.rate_select: int | None = None
        self.out_silent: bool | None = None
        self.sound: bool | None = None
        self.self_clean: bool | None = None

    def _220f4047_core_property_values(
        self,
    ) -> tuple[tuple[int, int | None], ...]:
        """Return encoded exact-model property values without packing them."""
        return (
            (
                MODEL_220F4047_SWING_UD_TAG,
                None
                if self.swing_vertical is None
                else MODEL_220F4047_SWING_ENABLED_VALUE
                if self.swing_vertical
                else 0x00,
            ),
            (
                MODEL_220F4047_SWING_LR_TAG,
                None
                if self.swing_horizontal is None
                else MODEL_220F4047_SWING_ENABLED_VALUE
                if self.swing_horizontal
                else 0x00,
            ),
            (
                MODEL_220F4047_ECO_TAG,
                None if self.eco_mode is None else int(self.eco_mode),
            ),
            (
                MODEL_220F4047_DRY_TAG,
                None if self.dry is None else int(self.dry),
            ),
            (
                MODEL_220F4047_POWER_SAVING_TAG,
                None if self.power_saving is None else int(self.power_saving),
            ),
        )

    def _pack_220f4047_core_properties(self) -> tuple[int, bytearray]:
        """Pack exact-model properties and return their count and bytes."""
        pack_count = 0
        payload = bytearray()
        for param, value in self._220f4047_core_property_values():
            if value is None:
                continue
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=param,
                    value=bytearray([value]),
                ),
            )
        if self.wind_deflector_ud is not None or self.wind_deflector_lr is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=MODEL_220F4047_WIND_DEFLECTOR_TAG,
                    value=bytearray(
                        [
                            self.wind_deflector_ud
                            if self.wind_deflector_ud is not None
                            else MODEL_220F4047_UNCHANGED_DEFLECTOR_VALUE,
                            self.wind_deflector_lr
                            if self.wind_deflector_lr is not None
                            else MODEL_220F4047_UNCHANGED_DEFLECTOR_VALUE,
                        ],
                    ),
                ),
            )
        if self.cool_hot_sense is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=MODEL_220F4047_COOL_HOT_SENSE_TAG,
                    value=bytearray([int(self.cool_hot_sense), *([0x00] * 7)]),
                ),
            )
        return pack_count, payload

    @property
    def _body(self) -> bytearray:
        pack_count = 0
        payload = bytearray([0x00])
        if self.mode_power is not None:
            power, mode, target_temperature, fan_speed = self.mode_power
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.mode_power,
                    value=bytearray(
                        [
                            int(power),
                            int(mode),
                            round(target_temperature * MODE_POWER_TEMPERATURE_SCALE),
                            int(fan_speed),
                        ],
                    ),
                ),
            )
        core_pack_count, core_payload = self._pack_220f4047_core_properties()
        pack_count += core_pack_count
        payload.extend(core_payload)
        if self.breezeless is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.breezeless,
                    value=bytearray([0x01 if self.breezeless else 0x00]),
                ),
            )
        if self.indirect_wind is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.indirect_wind,
                    value=bytearray([0x02 if self.indirect_wind else 0x01]),
                ),
            )
        if self.wind_straight is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.wind_straight,
                    value=bytearray([0x01 if self.wind_straight else 0x00]),
                ),
            )
        if self.wind_avoid is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.wind_avoid,
                    value=bytearray([0x01 if self.wind_avoid else 0x00]),
                ),
            )
        if self.light_sensitive is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.light_sensitive,
                    value=bytearray([self.light_sensitive]),
                ),
            )
        if self.prompt_tone is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.prompt_tone,
                    value=bytearray([0x01 if self.prompt_tone else 0x00]),
                ),
            )
        if self.screen_display_alternate is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.screen_display,
                    value=bytearray([0x64 if self.screen_display_alternate else 0x00]),
                ),
            )
        if self.fresh_air_1 is not None and len(self.fresh_air_1) == FRESH_AIR_LENGTH:
            pack_count += 1
            fresh_air_power = 2 if next(iter(self.fresh_air_1)) > 0 else 1
            fresh_air_fan_speed = list(self.fresh_air_1)[1]
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.fresh_air_1,
                    value=bytearray(
                        [
                            fresh_air_power,
                            fresh_air_fan_speed,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                            0x00,
                        ],
                    ),
                ),
            )
        if self.fresh_air_2 is not None and len(self.fresh_air_2) == FRESH_AIR_LENGTH:
            pack_count += 1
            fresh_air_power = 1 if next(iter(self.fresh_air_2)) > 0 else 0
            fresh_air_fan_speed = list(self.fresh_air_2)[1]
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.fresh_air_2,
                    value=bytearray([fresh_air_power, fresh_air_fan_speed, 0xFF]),
                ),
            )
        if self.wind_lr_angle is not None:
            pack_count += 1
            wind_lr_angle = int(self.wind_lr_angle)
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.wind_lr_angle,
                    value=bytearray([wind_lr_angle if wind_lr_angle else 0x00]),
                ),
            )
        if self.wind_ud_angle is not None:
            pack_count += 1
            wind_ud_angle = int(self.wind_ud_angle)
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.wind_ud_angle,
                    value=bytearray([wind_ud_angle if wind_ud_angle else 0x00]),
                ),
            )
        if self.out_silent is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.out_silent,
                    # Device requires 0x03 to activate, 0x00 to deactivate
                    # Sending 0x01 results in an error from the firmware
                    value=bytearray([OUT_SILENT_VALUE if self.out_silent else 0x00]),
                ),
            )
        if self.sound is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.buzzer_all,
                    value=bytearray([0x01 if self.sound else 0x00]),
                ),
            )
        if self.self_clean is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.self_clean,
                    value=bytearray([0x01 if self.self_clean else 0x00]),
                ),
            )
        if self.rate_select is not None:
            pack_count += 1
            payload.extend(
                NewProtocolMessageBody.pack(
                    param=NewProtocolTags.rate_select,
                    value=bytearray([int(self.rate_select)]),
                ),
            )
        payload[0] = pack_count
        return payload


class XA0Body(MessageBody):
    """AC A0 message body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize AC A0 message body."""
        super().__init__(body)
        self.power = (body[1] & 0x1) > 0  # powerValue
        # temperature & smallTemperature
        self.target_temperature = (
            ((body[1] & 0x3E) >> 1) - 4 + 16.0 + (0.5 if body[1] & 0x40 > 0 else 0.0)
        )
        self.mode = (body[2] & 0xE0) >> 5  # modeValue
        self.fan_speed = body[3] & 0x7F  # fanspeedValue
        self.swing_vertical = (body[7] & 0xC) > 0  # swingLRValue
        self.swing_horizontal = (body[7] & 0x3) > 0  # swingUDValue
        # strongWindValue
        self.boost_mode = ((body[8] & 0x20) > 0) or ((body[10] & 0x2) > 0)
        self.power_saving = (body[8] & POWER_SAVING_VALUE) > 0
        self.comfort_sleep = body[8] & 0x03  # comfortableSleepValue
        self.comfort_sleep_switch = body[14] & 0x01  # comfortableSleepSwitch
        self.pmv = ((body[11] & 0xF0) >> 4) * 0.5 - 3.5  # pmv
        # screenDisplayNowValue
        self.screen_display = (
            (body[14] >> 4 & 0x7) != SCREEN_DISPLAY_BYTE_CHECK
        ) and self.power
        self.smart_eye = (body[9] & 0x01) > 0
        self.dry = (body[9] & 0x04) > 0  # dryValue
        self.aux_heating = (body[9] & 0x08) > 0  # PTCValue
        self.purifier = body[9] & 0x20  # purifierValue
        self.anion = (body[9] & 0x20) > 0
        self.eco_mode = (body[9] & 0x10) > 0  # ecoValue
        self.sleep_mode = (body[10] & 0x01) > 0
        self.natural_wind = (body[10] & 0x40) > 0  # naturalWind
        self.smart_dry = body[13] & 0x7F  # smartDryValue
        self.kick_quilt = (body[10] & 0x04) >> 2  # kickQuilt
        self.prevent_cold = (body[10] & 0x08) >> 3  # preventCold
        self.full_dust = ((body[13] & 0x20) >> 5) > 0  # dust_full_time
        # comfortPowerSave
        self.comfort_mode = (
            (body[14] & 0x1) > 0 if len(body) > CONFORT_MODE_MIN_LENGTH else False
        )
        # smartDryValue
        self.smart_dry = (body[13] & 0x7F) > 0
        # swingLRUnderSwitch
        self.swing_lr_switch = (
            body[19] & 0x80 if len(body) >= SWING_LR_MIN_LENGTH else 0
        )
        # swingLRValueUnder
        self.swing_lr_value = body[9] & 0x40
        # arom
        self.frost_protect = (
            ((body[21] & 0x80) >> 7) > 0
            if len(body) >= FROST_PROTECT_MIN_LENGTH
            else False
        )
        if len(body) >= FRESH_AIR_C0_MIN_LENGTH:
            self.fresh_filter_time_total = body[25] * 256 + body[24]
            self.fresh_filter_time_use = body[16] * 256 + body[15]
            self.fresh_filter_timeout = (body[13] & 0x40) >> 6


class XMessageBody(MessageBody):
    """AC A1/C0 message body - common functions."""

    @staticmethod
    def parse_temperature(
        integer: int,
        decimal: int,
        offset: int = C0_DEFAULT_TEMPERATURE_OFFSET,
    ) -> float | None:
        """Decode special signed integer with BCD decimal temperature format."""
        if integer == MAX_BYTE_VALUE:
            return None
        temp_integer = (integer - offset) / 2
        if decimal == 0:
            return temp_integer
        if temp_integer < 0:
            return int(temp_integer) - decimal * 0.1
        return int(temp_integer) + decimal * 0.1


class XA1Body(XMessageBody):
    """AC A1 message body."""

    def __init__(self, body: bytearray) -> None:
        """Initialize AC A1 message body."""
        super().__init__(body)
        # currentWorkTime
        self.current_work_time = (
            (((body[9] << 8) & 0xFF00) | (body[10] & 0x00FF)) * 60 * 24
            + body[11] * 60
            + body[12]
        )
        decimal = body[18] if len(body) > TEMP_DECIMAL_MIN_BODY_LENGTH else 0
        self.indoor_temperature = self.parse_temperature(body[13], decimal & 0x0F)
        self.outdoor_temperature = self.parse_temperature(body[14], decimal >> 4)
        self.indoor_humidity = body[17] if body[17] != 0 else None


class PropertiesBody(NewProtocolMessageBody):
    """AC Bx message body. body[0] b0/b1, body[1] propertyNumber, cursor 2."""

    def __init__(
        self,
        body: bytearray,
        new_protocol_temperature: bool = False,
        supports_220f4047_core_properties: bool = False,
    ) -> None:
        """Initialize AC BX message body."""
        # PyPI 2026.8.0 still requires the body-type argument, while current
        # source derives it from the body. Pass it explicitly so an AC parser
        # built from this tree works with either base implementation.
        super().__init__(body, body[0])

        params = self.parse()
        if NewProtocolTags.indirect_wind in params:
            self.indirect_wind = (
                params[NewProtocolTags.indirect_wind][0] == INDIRECT_WIND_VALUE
            )
        if NewProtocolTags.indoor_humidity in params:
            indoor_humidity = params[NewProtocolTags.indoor_humidity][0]
            self.indoor_humidity = indoor_humidity if indoor_humidity != 0 else None
        if NewProtocolTags.breezeless in params:
            self.breezeless = params[NewProtocolTags.breezeless][0] == 1
        if NewProtocolTags.screen_display in params:
            self.screen_display_alternate = (
                params[NewProtocolTags.screen_display][0] > 0
            )
            self.screen_display_new = True
        if NewProtocolTags.fresh_air_1 in params:
            self.fresh_air_1 = True
            data = params[NewProtocolTags.fresh_air_1]
            self.fresh_air_power = data[0] == INDIRECT_WIND_VALUE
            self.fresh_air_fan_speed = data[1]
        if NewProtocolTags.fresh_air_2 in params:
            self.fresh_air_2 = True
            data = params[NewProtocolTags.fresh_air_2]
            self.fresh_air_power = data[0] > 0
            self.fresh_air_fan_speed = data[1]
        if supports_220f4047_core_properties:
            self._parse_220f4047_core_properties(params)
        else:
            if NewProtocolTags.wind_lr_angle in params:
                self.wind_lr_angle = params[NewProtocolTags.wind_lr_angle][0]
            if NewProtocolTags.wind_ud_angle in params:
                self.wind_ud_angle = params[NewProtocolTags.wind_ud_angle][0]
        if NewProtocolTags.rate_select in params:
            self.rate_select = params[NewProtocolTags.rate_select][0]
        if NewProtocolTags.out_silent in params:
            self.out_silent = params[NewProtocolTags.out_silent][0] == OUT_SILENT_VALUE
        self._parse_optional_feature_states(params)
        if NewProtocolTags.buzzer_all in params:
            self.sound = params[NewProtocolTags.buzzer_all][0] > 0
        if NewProtocolTags.error_code_query in params:
            self.error_code = params[NewProtocolTags.error_code_query][0]
        if NewProtocolTags.self_clean in params and self.body_type != ListTypes.B5:
            # A B5 body carries this tag as a capability flag (always 1 when the
            # model supports self-clean), so only B0/B1 bodies report live state.
            self.self_clean_active: bool = params[NewProtocolTags.self_clean][0] > 0
        if (
            new_protocol_temperature
            and NEW_PROTOCOL_TEMPERATURE_TAG in params
            and self._parse_new_protocol_temperatures(
                params[NEW_PROTOCOL_TEMPERATURE_TAG],
            )
        ):
            self.has_new_protocol_temperature = True

    def _parse_optional_feature_states(
        self,
        params: Mapping[int, bytearray],
    ) -> None:
        """Decode the optional states queried by exact-model probes."""
        if NewProtocolTags.comfort_sleep in params:
            self.comfort_sleep = params[NewProtocolTags.comfort_sleep][0] > 0
        if NewProtocolTags.wind_straight in params:
            wind_straight = params[NewProtocolTags.wind_straight][0]
            self.wind_straight = wind_straight == WIND_STRAIGHT_VALUE
            # Some SN8 variants encode wind avoidance as value 2 on tag 0x0032
            # instead of using the dedicated 0x0033 tag.
            self.yb_wind_avoid = wind_straight == YB_WIND_AVOID_VALUE
        if NewProtocolTags.wind_avoid in params:
            self.wind_avoid = params[NewProtocolTags.wind_avoid][0] > 0
        if NewProtocolTags.nobody_energy_save in params:
            self.nobody_energy_save = params[NewProtocolTags.nobody_energy_save][0] > 0
        if NewProtocolTags.nobody_energy_save_tag in params:
            # Preserve this newer variant as a raw value until a real-device
            # capture establishes whether its values are strictly boolean.
            self.nobody_energy_save_tag = params[
                NewProtocolTags.nobody_energy_save_tag
            ][0]
        if NewProtocolTags.light_sensitive in params:
            # The model script exposes this byte unchanged. Preserve it so the
            # first real-device capture can establish its on/off value mapping.
            self.light_sensitive = params[NewProtocolTags.light_sensitive][0]
        if NewProtocolTags.filter_level in params:
            filter_data = params[NewProtocolTags.filter_level]
            if len(filter_data) >= FILTER_MIN_PAYLOAD_LENGTH:
                self.filter_level = filter_data[FILTER_LEVEL_INDEX]
                self.filter_value = filter_data[FILTER_VALUE_INDEX]

    def _parse_220f4047_core_properties(
        self,
        params: Mapping[int, bytearray],
    ) -> None:
        """Decode the source-backed subtype-8 controls for model 220F4047."""
        if MODEL_220F4047_SWING_UD_TAG in params:
            self.swing_vertical = params[MODEL_220F4047_SWING_UD_TAG][0] > 0
        if MODEL_220F4047_SWING_LR_TAG in params:
            self.swing_horizontal = params[MODEL_220F4047_SWING_LR_TAG][0] > 0
        if MODEL_220F4047_WIND_DEFLECTOR_TAG in params:
            deflector = params[MODEL_220F4047_WIND_DEFLECTOR_TAG]
            if (
                len(deflector) >= 1
                and deflector[0] != MODEL_220F4047_UNCHANGED_DEFLECTOR_VALUE
            ):
                self.wind_ud_angle = deflector[0]
            if (
                len(deflector) >= MODEL_220F4047_DEFLECTOR_PAYLOAD_LENGTH
                and deflector[1] != MODEL_220F4047_UNCHANGED_DEFLECTOR_VALUE
            ):
                self.wind_lr_angle = deflector[1]
        if MODEL_220F4047_ECO_TAG in params:
            self.eco_mode = params[MODEL_220F4047_ECO_TAG][0] > 0
        if MODEL_220F4047_DRY_TAG in params:
            self.dry = params[MODEL_220F4047_DRY_TAG][0] > 0
        if MODEL_220F4047_COOL_HOT_SENSE_TAG in params:
            self.cool_hot_sense = params[MODEL_220F4047_COOL_HOT_SENSE_TAG][0] > 0
        if MODEL_220F4047_POWER_SAVING_TAG in params:
            self.power_saving = params[MODEL_220F4047_POWER_SAVING_TAG][0] > 0

    def _parse_new_protocol_temperatures(self, data: bytearray) -> bool:
        """Decode setpoint and indoor temperature for model 22013279.

        Its standard C0 temperature fields are stale; temperatures are reported
        in this new-protocol tag instead. Synced captures show the setpoint in
        byte 1:
        - low 6 bits encode 0.5C steps with a +11.5C offset
        - bit 0x40 adds an extra +0.5C

        Only call this for model 22013279. For other models, this tag is not
        known to supersede C0; accepting it would latch B1 values and discard
        C0 temperatures, including any outdoor reading.
        """
        if len(data) <= NEW_PROTOCOL_TEMPERATURE_MIN_LENGTH:
            return False
        raw_setpoint = data[1]
        target_temperature = (
            NEW_PROTOCOL_SETPOINT_OFFSET
            + (raw_setpoint & NEW_PROTOCOL_SETPOINT_MASK) / 2
        )
        if raw_setpoint & NEW_PROTOCOL_SETPOINT_HALF_DEGREE_BIT:
            target_temperature += 0.5
        if not (
            NEW_PROTOCOL_MIN_VALID_TEMPERATURE
            <= target_temperature
            <= NEW_PROTOCOL_MAX_VALID_TEMPERATURE
        ):
            # Fallback for payload variants where the legacy byte-3 mapping
            # is still active.
            fallback_target = (data[NEW_PROTOCOL_LEGACY_SETPOINT_BYTE] - 50) / 2
            if (
                NEW_PROTOCOL_MIN_VALID_TEMPERATURE
                <= fallback_target
                <= NEW_PROTOCOL_MAX_VALID_TEMPERATURE
            ):
                target_temperature = fallback_target
            else:
                return False
        indoor_temperature = round(
            (data[NEW_PROTOCOL_INDOOR_TEMPERATURE_BYTE] - 50) / 2
            + data[NEW_PROTOCOL_INDOOR_TEMPERATURE_DECIMAL_BYTE] * 0.1,
            1,
        )
        if not (
            NEW_PROTOCOL_MIN_VALID_TEMPERATURE
            <= indoor_temperature
            <= NEW_PROTOCOL_MAX_VALID_TEMPERATURE
        ):
            return False
        self.target_temperature = target_temperature
        self.indoor_temperature = indoor_temperature
        # Outdoor temperature isn't available locally on this model (the app
        # shows a cloud/weather value); avoid the bogus C0-derived value.
        self.outdoor_temperature = None
        return True


class CapabilityBody(NewProtocolMessageBody):
    """AC B5 capability response body. body[0] b5, body[1] propertyNumber."""

    def __init__(self, body: bytearray) -> None:
        """Initialize AC B5 capability response message body."""
        # Keep compatibility with the released 2026.8.0 base constructor.
        super().__init__(body, body[0])

        params = self.parse()
        # parse b5 protocol, github issue https://github.com/wuwentao/midea_ac_lan/issues/673
        if NewProtocolTags.b5_mode in params:
            self.b5_mode = params[NewProtocolTags.b5_mode][0]
        if NewProtocolTags.b5_anion in params:
            self.b5_anion = params[NewProtocolTags.b5_anion][0]
        if NewProtocolTags.b5_filter_remind in params:
            self.b5_filter_remind = params[NewProtocolTags.b5_filter_remind][0]
        if NewProtocolTags.b5_strong_wind in params:
            self.b5_strong_wind = params[NewProtocolTags.b5_strong_wind][0]
        if NewProtocolTags.b5_wind_speed in params:
            self.b5_wind_speed = params[NewProtocolTags.b5_wind_speed][0]
        if NewProtocolTags.b5_temperature in params:
            self.b5_temperature0 = params[NewProtocolTags.b5_temperature][0]
            self.b5_temperature1 = params[NewProtocolTags.b5_temperature][1]
            self.b5_temperature2 = params[NewProtocolTags.b5_temperature][2]
            self.b5_temperature3 = params[NewProtocolTags.b5_temperature][3]
            self.b5_temperature4 = params[NewProtocolTags.b5_temperature][4]
            self.b5_temperature5 = params[NewProtocolTags.b5_temperature][5]
            self.b5_temperature6 = params[NewProtocolTags.b5_temperature][6]
            # per-mode setpoint limits in 0.5 C units. the six raw bytes are
            # cool then auto then heat, each a min then a max, plus a flag byte.
            # keyed by mode value: auto is 1, cool 2, dry 3, heat 4, fan 5
            # (dry and fan reuse the cool range).
            cool = (self.b5_temperature0 / 2, self.b5_temperature1 / 2)
            auto = (self.b5_temperature2 / 2, self.b5_temperature3 / 2)
            heat = (self.b5_temperature4 / 2, self.b5_temperature5 / 2)
            self.temperature_limits = {1: auto, 2: cool, 3: cool, 4: heat, 5: cool}
        if NewProtocolTags.b5_screen_display in params:
            self.b5_screen_display = params[NewProtocolTags.b5_screen_display][0]
        if NewProtocolTags.buzzer_all in params:
            # b5_sound/buzzer_all
            self.b5_sound = params[NewProtocolTags.buzzer_all][0]
        if NewProtocolTags.b5_humidity in params:
            self.b5_humidity = params[NewProtocolTags.b5_humidity][0]
        self._parse_capabilities(params)

    def _parse_capabilities(self, params: dict[int, bytearray]) -> None:
        """Decode B5 capability values into feature flags.

        The raw byte of each capability is not a simple 0/1 flag; each one has
        its own value semantics (reverse-engineered, matching the msmart
        project). Only capabilities actually reported are added.
        """
        caps: dict[str, bool] = {}
        if NewProtocolTags.b5_mode in params:
            value = params[NewProtocolTags.b5_mode][0]
            caps["heat_mode"] = value in B5_HEAT_MODE_VALUES
            caps["cool_mode"] = value not in B5_NO_COOL_MODE_VALUES
            caps["dry_mode"] = value in B5_DRY_MODE_VALUES
            caps["auto_mode"] = value in B5_AUTO_MODE_VALUES
        if NewProtocolTags.b5_wind_swing in params:
            value = params[NewProtocolTags.b5_wind_swing][0]
            caps["swing_horizontal"] = value in B5_SWING_HORIZONTAL_VALUES
            caps["swing_vertical"] = value < B5_LOW_VALUE_MAX
        if NewProtocolTags.b5_wind_speed in params:
            value = params[NewProtocolTags.b5_wind_speed][0]
            fan_custom = value == B5_FAN_CUSTOM_VALUE
            caps["fan_silent"] = fan_custom or value in B5_FAN_SILENT_VALUES
            caps["fan_low"] = fan_custom or value in B5_FAN_LOW_HIGH_VALUES
            caps["fan_medium"] = fan_custom or value in B5_FAN_MEDIUM_VALUES
            caps["fan_high"] = fan_custom or value in B5_FAN_LOW_HIGH_VALUES
            caps["fan_auto"] = fan_custom or value in B5_FAN_AUTO_VALUES
            caps["fan_custom"] = fan_custom
        if NewProtocolTags.b5_eco in params:
            caps["eco"] = params[NewProtocolTags.b5_eco][0] in B5_ECO_VALUES
        if NewProtocolTags.b5_anion in params:
            caps["anion"] = params[NewProtocolTags.b5_anion][0] == B5_ANION_ON_VALUE
        if NewProtocolTags.b5_strong_wind in params:
            value = params[NewProtocolTags.b5_strong_wind][0]
            caps["turbo_cool"] = value < B5_LOW_VALUE_MAX
            caps["turbo_heat"] = value in B5_TURBO_HEAT_VALUES
        if NewProtocolTags.b5_screen_display in params:
            value = params[NewProtocolTags.b5_screen_display][0]
            caps["display_control"] = value in B5_DISPLAY_VALUES
        if NewProtocolTags.b5_electricity in params:
            value = params[NewProtocolTags.b5_electricity][0]
            caps["rate_select"] = value > B5_ELECTRICITY_UNSUPPORTED_VALUE
        self.capabilities = caps


class StateBody(XMessageBody):
    """AC C0 message body."""

    def __init__(
        self,
        body: bytearray,
        indoor_temperature_offset: int = C0_DEFAULT_TEMPERATURE_OFFSET,
        invalid_outdoor_temperature_values: frozenset[
            int
        ] = C0_DEFAULT_INVALID_OUTDOOR_TEMPERATURE_VALUES,
    ) -> None:
        """Initialize AC C0 message body."""
        super().__init__(body)
        self.power = (body[1] & 0x1) > 0  # powerValue
        self.mode = (body[2] & 0xE0) >> 5  # modeValue
        self.target_temperature = (
            (body[2] & 0x0F) + 16.0 + (0.5 if body[0x02] & 0x10 > 0 else 0.0)
        )  # temperature + smallTemperature
        self.fan_speed = body[3] & 0x7F  # fanspeedValue
        self.swing_vertical = (body[7] & 0x0C) > 0  # swingUDValue
        self.swing_horizontal = (body[7] & 0x03) > 0  # swingLRValue
        # strongWindValue
        self.boost_mode = ((body[8] & 0x20) > 0) or ((body[10] & 0x2) > 0)
        self.power_saving = (body[8] & POWER_SAVING_VALUE) > 0
        self.comfort_sleep = body[8] & 0x03  # comfortableSleepValue
        self.comfort_sleep_switch = body[9] & 0x40  # comfortableSleepSwitch
        self.pmv = (body[14] & 0x0F) * 0.5 - 3.5  # pmv
        self.smart_eye = (body[8] & 0x40) > 0
        self.natural_wind = (body[9] & 0x2) > 0  # naturalWind
        self.dry = (body[9] & 0x4) > 0  # dryValue
        self.eco_mode = (body[9] & 0x10) > 0  # ecoValue
        self.aux_heating = (body[9] & 0x08) > 0  # PTCValue
        self.purifier = body[9] & 0x20  # purifierValue
        self.anion = (body[9] & 0x20) > 0
        self.temp_fahrenheit = (body[10] & 0x04) > 0
        self.sleep_mode = (body[10] & 0x01) > 0
        decimal = body[15] if len(body) > TEMP_DECIMAL_MIN_BODY_LENGTH else 0
        self.indoor_temperature = self.parse_temperature(
            body[11],
            decimal & 0x0F,
            indoor_temperature_offset,
        )
        outdoor_temperature = body[12]
        self.outdoor_temperature = (
            None
            if outdoor_temperature in invalid_outdoor_temperature_values
            else self.parse_temperature(outdoor_temperature, decimal >> 4)
        )
        self.kick_quilt = (body[10] & 0x04) >> 2  # kickQuilt
        self.prevent_cold = (body[10] & 0x20) >> 5  # preventCold
        self.full_dust = ((body[13] & 0x20) >> 5) > 0  # dust_full_time
        # screenDisplayNowValue
        self.screen_display = (
            (body[14] >> 4 & 0x7) != SCREEN_DISPLAY_BYTE_CHECK
        ) and self.power
        # arom
        self.frost_protect = (
            (body[21] & 0x80) > 0 if len(body) >= FROST_PROTECT_MIN_LENGTH else False
        )
        # comfortPowerSave
        self.comfort_mode = (
            (body[22] & 0x1) > 0 if len(body) >= CONFORT_MODE_MIN_LENGTH2 else False
        )
        # smartDryValue
        self.smart_dry = (
            (body[19] & 0x7F) > 0 if len(body) >= SMART_DRY_MIN_LENGTH else False
        )
        # swingLRUnderSwitch
        self.swing_lr_switch = (
            body[19] & 0x80 if len(body) >= SWING_LR_MIN_LENGTH else 0
        )
        # swingLRValueUnder
        self.swing_lr_value = body[20] & 0x80 if len(body) >= SWING_LR_MIN_LENGTH else 0
        if len(body) >= FRESH_AIR_C0_MIN_LENGTH:
            self.fresh_filter_time_total = body[25] * 256 + body[24]
            self.fresh_filter_time_use = body[27] * 256 + body[26]
            self.fresh_filter_timeout = (body[13] & 0x40) >> 6


class GroupBody(MessageBody):
    """AC C1 message body."""

    def __init__(self, body: bytearray, analysis_method: int = 3) -> None:
        """Initialize AC C1 message body."""
        super().__init__(body)
        if len(body) <= XC1_SUBBODY_TYPE_INDEX:
            return
        group_type = body[XC1_SUBBODY_TYPE_INDEX]
        if group_type == XC1_SUBBODY_TYPE_44:
            if len(body) < XC1_CONSUMPTION_MIN_LENGTH:
                return

            def parse_consumption(data: bytearray) -> float:
                return self.parse_consumption(analysis_method, data)

            # total_power_consumption
            self.total_energy_consumption = parse_consumption(body[4:8])
            # total_operating_consumption
            self.total_operating_consumption = parse_consumption(body[8:12])
            # current_operating_consumption
            self.current_energy_consumption = parse_consumption(body[12:16])
            # current_time_power
            self.realtime_power = self.parse_power(analysis_method, body[16:19])
        elif group_type == XC1_SUBBODY_TYPE_41:
            self._parse_group_one(body)
        elif group_type == XC1_SUBBODY_TYPE_42:
            self._parse_group_two(body)
        elif group_type == XC1_SUBBODY_TYPE_47:
            self._parse_group_seven(body)
        elif group_type == XC1_SUBBODY_TYPE_40:
            if len(body) < XC1_OPERATING_TIME_MIN_LENGTH:
                return
            self.electrify_time_day = body[5] | (body[4] << 8)
            self.electrify_time_hour = body[6]
            self.electrify_time_min = body[7]
            self.electrify_time_second = body[8]
            # summary
            self.electrify_time = (
                (self.electrify_time_day * 24)
                + self.electrify_time_hour
                + (self.electrify_time_min / 60)
                + (self.electrify_time_second / 3600)
            )
            self.total_operating_time_day = body[10] | (body[9] << 8)
            self.total_operating_time_hour = body[11]
            self.total_operating_time_min = body[12]
            self.total_operating_time_second = body[13]
            # summary
            self.total_operating_time = (
                (self.total_operating_time_day * 24)
                + self.total_operating_time_hour
                + (self.total_operating_time_min / 60)
                + (self.total_operating_time_second / 3600)
            )
            self.current_operating_time_day = body[15] | (body[14] << 8)
            self.current_operating_time_hour = body[16]
            self.current_operating_time_min = body[17]
            self.current_operating_time_second = body[18]
            # summary
            self.current_operating_time = (
                (self.current_operating_time_day * 24)
                + self.current_operating_time_hour
                + (self.current_operating_time_min / 60)
                + (self.current_operating_time_second / 3600)
            )
        elif group_type == XC1_SUBBODY_TYPE_45:
            if len(body) <= XC1_HUMIDITY_INDEX:
                return
            # indoor humidity, it should be the same value as XBB/XA1 message
            self.indoor_humidity = body[4] if body[4] != 0 else None

    def _parse_group_one(self, body: bytearray) -> None:
        """Parse group 1 data: compressor and refrigerant circuit.

        This is service/engineering data that the Midea app does not display,
        so it is not covered by any B5 capability and is simply absent on
        devices that do not answer the group 1 query.
        """
        if len(body) < XC1_GROUP_ONE_MIN_LENGTH:
            return
        self.compressor_frequency = body[4]
        self.target_compressor_frequency = body[5]
        self.compressor_current = body[7]
        self.compressor_voltage = body[8]
        # T1: indoor return air, T2: indoor coil
        self.indoor_ambient_temperature = (
            body[10] - XC1_TEMP_INDOOR_OFFSET
        ) / XC1_TEMP_DIVISOR
        self.indoor_coil_temperature = (
            body[11] - XC1_TEMP_INDOOR_OFFSET
        ) / XC1_TEMP_DIVISOR
        # T3: outdoor coil, T4: outdoor ambient
        self.outdoor_coil_temperature = (
            body[12] - XC1_TEMP_OUTDOOR_OFFSET
        ) / XC1_TEMP_DIVISOR
        self.outdoor_ambient_temperature = (
            body[13] - XC1_TEMP_OUTDOOR_OFFSET
        ) / XC1_TEMP_DIVISOR
        # TP: compressor discharge pipe, reported directly in degrees
        self.discharge_pipe_temperature = body[14]

    def _parse_group_two(self, body: bytearray) -> None:
        """Parse group 2 data: indoor fan and condensate pump."""
        if len(body) < XC1_GROUP_TWO_MIN_LENGTH:
            return
        self.target_indoor_fan_speed = body[4] * XC1_FAN_SPEED_FACTOR
        self.indoor_fan_speed = body[5] * XC1_FAN_SPEED_FACTOR
        # Could also be the float switch (tank full) that triggers the pump.
        self.water_pump_running = bool(body[8] & XC1_WATER_PUMP_MASK)

    def _parse_group_seven(self, body: bytearray) -> None:
        """Parse group 7 data: real time compressor power."""
        if len(body) < XC1_GROUP_SEVEN_MIN_LENGTH:
            return
        self.compressor_power = body[10] + (body[11] << 8)

    power_analysis_methods: Mapping[int, Callable[[int, int], int]] = MappingProxyType(
        {
            PowerFormats.BCD: lambda byte, value: (
                (byte >> 4) * 10 + (byte & 0x0F) + value * 100
            ),
            PowerFormats.BINARY: lambda byte, value: byte + (value << 8),
            PowerFormats.MIXED: lambda byte, value: byte + value * 100,
        },
    )

    @classmethod
    def parse_value(cls, analysis_method: int, databytes: bytearray) -> float:
        """AC C1 message body parse value."""
        if analysis_method not in PowerFormats._value2member_map_:
            return 0.0  # unknown method
        analysis_function = cls.power_analysis_methods[analysis_method % 10]
        value = 0
        for byte in databytes:
            value = analysis_function(byte, value)
        return float(value)

    @classmethod
    def parse_power(cls, analysis_method: int, databytes: bytearray) -> float:
        """AC C1 message body parse power."""
        if analysis_method == PowerFormats.BCD_ENERGY_BINARY_POWER:
            return cls.parse_value(PowerFormats.BINARY, databytes) / 10
        return cls.parse_value(analysis_method, databytes) / 10

    @classmethod
    def parse_consumption(cls, analysis_method: int, databytes: bytearray) -> float:
        """AC C1 message body parse consumption."""
        if analysis_method == PowerFormats.BCD_ENERGY_BINARY_POWER:
            return cls.parse_value(PowerFormats.BCD, databytes) / 100
        # LSB = 0.01 kWh, except for default binary format = 0.1 kWh
        divisor = 10 if analysis_method == PowerFormats.BINARY else 100
        return cls.parse_value(analysis_method, databytes) / divisor


class SubProtocolBody(MessageBody):
    """AC BB message body."""

    def __init__(self, body: bytearray) -> None:
        """Initializ AC BB message body."""
        super().__init__(body)
        subprotocol_head = body[:6]
        subprotocol_body = body[6:]
        data_type = subprotocol_head[-1]
        subprotocol_body_len = len(subprotocol_body)
        if (
            data_type in (ListTypes.X11, ListTypes.X20)
            and subprotocol_body_len > BB_BASIC_FAN_SPEED_INDEX
        ):
            self.power = (subprotocol_body[0] & 0x1) > 0
            self.dry = (subprotocol_body[0] & 0x10) > 0
            self.boost_mode = (subprotocol_body[0] & 0x20) > 0
            self.aux_heating = (subprotocol_body[1] & 0x40) > 0
            self.sleep_mode = (subprotocol_body[2] & 0x80) > 0
            try:
                self.mode = BB_AC_MODES.index(subprotocol_body[5] + 1)
            except ValueError:
                self.mode = 0
            self.target_temperature = (subprotocol_body[6] - 30) / 2
            self.fan_speed = subprotocol_body[7]
            self.timer = (
                (subprotocol_body[25] & 0x04) > 0
                if subprotocol_body_len > TIMER_MIN_SUBPROTOCOL_LENGTH
                else False
            )
            self.eco_mode = (
                (subprotocol_body[25] & 0x40) > 0
                if subprotocol_body_len > ECO_MODE_MIN_SUBPROTOCOL_LENGTH
                else False
            )
            # These offsets are known for the verified BB fresh-air model; the
            # device layer gates public attributes and controls to that model.
            if subprotocol_body_len > BB_FRESH_AIR_EXHAUST_SPEED_INDEX:
                fresh_air_switches = subprotocol_body[BB_FRESH_AIR_SWITCH_INDEX]
                self.bb_fresh_air_power = bool(
                    fresh_air_switches & BB_FRESH_AIR_INTAKE_STATUS_MASK,
                )
                self.bb_fresh_air_fan_speed = subprotocol_body[
                    BB_FRESH_AIR_INTAKE_SPEED_INDEX
                ]
                self.bb_fresh_air_exhaust_power = bool(
                    fresh_air_switches & BB_FRESH_AIR_EXHAUST_STATUS_MASK,
                )
                self.bb_fresh_air_exhaust_speed = subprotocol_body[
                    BB_FRESH_AIR_EXHAUST_SPEED_INDEX
                ]
        elif data_type == ListTypes.X10:
            if subprotocol_body_len > BB_INDOOR_TEMPERATURE_HIGH_INDEX:
                if subprotocol_body[8] & 0x80 == SUB_PROTOCOL_BODY_TEMP_CHECK:
                    self.indoor_temperature = (
                        0 - (~(subprotocol_body[7] + subprotocol_body[8] * 256) + 1)
                        & 0xFFFF
                    ) / 100
                else:
                    self.indoor_temperature = (
                        subprotocol_body[7] + subprotocol_body[8] * 256
                    ) / 100
            if subprotocol_body_len > BB_INDOOR_HUMIDITY_INDEX:
                self.indoor_humidity = (
                    subprotocol_body[30] if subprotocol_body[30] != 0 else None
                )
            if subprotocol_body_len > BB_SN8_FLAG_INDEX:
                self.sn8_flag = subprotocol_body[80] == XBB_SN8_BYTE_FLAG
        elif data_type == ListTypes.X12:
            pass
        elif data_type == ListTypes.X30:
            if subprotocol_body_len > BB_OUTDOOR_TEMPERATURE_HIGH_INDEX:
                if subprotocol_body[6] & 0x80 == SUB_PROTOCOL_BODY_TEMP_CHECK:
                    self.outdoor_temperature = (
                        0 - (~(subprotocol_body[5] + subprotocol_body[6] * 256) + 1)
                        & 0xFFFF
                    ) / 100
                else:
                    self.outdoor_temperature = (
                        subprotocol_body[5] + subprotocol_body[6] * 256
                    ) / 100
            if subprotocol_body_len > BB_COMPRESSOR_FREQUENCY_INDEX:
                self.target_compressor_frequency = subprotocol_body[
                    BB_COMPRESSOR_TARGET_FREQUENCY_INDEX
                ]
                self.compressor_frequency = subprotocol_body[
                    BB_COMPRESSOR_FREQUENCY_INDEX
                ]
        elif data_type in (ListTypes.X13, ListTypes.X21):
            pass


class MessageACResponse(MessageResponse):
    """AC message response."""

    def __init__(
        self,
        message: bytearray,
        power_analysis_method: int = 3,
        new_protocol_temperature: bool = False,
        supports_220f4047_core_properties: bool = False,
        c0_indoor_temperature_offset: int = C0_DEFAULT_TEMPERATURE_OFFSET,
        c0_invalid_outdoor_temperature_values: frozenset[
            int
        ] = C0_DEFAULT_INVALID_OUTDOOR_TEMPERATURE_VALUES,
    ) -> None:
        """Initialize AC message response."""
        super().__init__(message)
        # dataType 0x05 and messageBytes[0] 0xA0
        if self.message_type == MessageType.notify2 and self.body_type == ListTypes.A0:
            self.set_body(XA0Body(super().body))
        # dataType 0x04 and messageBytes[0] 0xA1
        elif (
            self.message_type == MessageType.notify1
            and self.body_type == ListTypes.A1
            and len(super().body) >= A1_MIN_BODY_LENGTH
        ):
            self.set_body(XA1Body(super().body))
        elif (
            self.message_type == MessageType.notify1 and self.body_type == ListTypes.A1
        ):
            _LOGGER.debug(
                "Skipping notify1 A1 body too short to parse (%d < %d bytes): %s",
                len(super().body),
                A1_MIN_BODY_LENGTH,
                super().body.hex(),
            )
        # parse CapabilitiesQuery/CapabilitiesAdditionalQuery response
        # dataType 0x03 and messageBytes[0] 0xB5
        elif self.message_type == MessageType.query and self.body_type == ListTypes.B5:
            self.set_body(CapabilityBody(super().body))
        # dataType 0x05 and messageBytes[0] 0xB5
        # dataType 0x02 and messageBytes[0] 0xB0 (set result Unidentified protocol)
        # dataType 0x03 and messageBytes[0] 0xB1
        elif self.message_type in [
            MessageType.query,
            MessageType.set,
            MessageType.notify2,
        ] and self.body_type in [ListTypes.B0, ListTypes.B1, ListTypes.B5]:
            self.set_body(
                PropertiesBody(
                    super().body,
                    new_protocol_temperature,
                    supports_220f4047_core_properties,
                ),
            )
        # dataType 0x02 and messageBytes[0] 0xC0
        # dataType 0x03 and messageBytes[0] 0xC0
        elif (
            self.message_type in [MessageType.query, MessageType.set]
            and self.body_type == ListTypes.C0
        ):
            self.set_body(
                StateBody(
                    super().body,
                    c0_indoor_temperature_offset,
                    c0_invalid_outdoor_temperature_values,
                ),
            )
        # messageBytes[0] 0xC1
        elif self.message_type == MessageType.query and self.body_type == ListTypes.C1:
            self.set_body(GroupBody(super().body, power_analysis_method))
        elif (
            self.message_type
            in [MessageType.set, MessageType.query, MessageType.notify2]
            and self.body_type == ListTypes.BB
            and len(super().body) >= BB_MIN_BODY_LENGTH
        ):
            self.used_subprotocol = True
            self.set_body(SubProtocolBody(super().body))

        self.set_attr()
