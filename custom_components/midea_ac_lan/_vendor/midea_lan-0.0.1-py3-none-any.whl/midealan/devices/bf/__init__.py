"""Midea local BF device."""

import logging
from enum import StrEnum
from typing import Any, Unpack

from midealan.const import DeviceType
from midealan.device import MideaDevice, MideaDeviceInitKwargs

from .message import (
    WORK_MODE_MAP,
    FirePower,
    MessageBFResponse,
    MessageQuery,
    MessageSet,
    WorkStatus,
)

_LOGGER = logging.getLogger(__name__)


class DeviceAttributes(StrEnum):
    """Midea BF device attributes."""

    # Basic status
    door = "door"
    status = "status"
    time_remaining = "time_remaining"
    current_temperature = "current_temperature"
    tank_ejected = "tank_ejected"
    water_change_reminder = "water_change_reminder"
    water_shortage = "water_shortage"
    # Work mode and cooking params
    work_mode = "work_mode"
    fire_power = "fire_power"
    pre_heat = "pre_heat"
    turntable = "turntable"
    hot_wind = "hot_wind"
    # Temperature settings
    temperature = "temperature"
    temperature_above = "temperature_above"
    temperature_underside = "temperature_underside"
    probe_temperature = "probe_temperature"
    # Current temperatures
    cur_temperature_above = "cur_temperature_above"
    cur_temperature_underside = "cur_temperature_underside"
    cur_probe_temperature = "cur_probe_temperature"
    # Cooking params
    steam_quantity = "steam_quantity"
    weight = "weight"
    people_number = "people_number"
    # Time settings
    hour_set = "hour_set"
    minute_set = "minute_set"
    second_set = "second_set"
    # Status flags
    child_lock = "child_lock"
    furnace_light = "furnace_light"
    flip_side = "flip_side"
    reaction = "reaction"
    high_temperature_lock = "high_temperature_lock"
    high_temperature_work = "high_temperature_work"
    high_temperature = "high_temperature"
    probe_mode = "probe_mode"
    probe = "probe"
    error = "error"
    ramadan = "ramadan"
    # Multi-stage cooking
    totalstep = "totalstep"
    stepnum = "stepnum"
    cloudmenuid = "cloudmenuid"
    # Maintenance
    clean_scale = "clean_scale"
    clean_sink_ponding = "clean_sink_ponding"
    dissipate_heat = "dissipate_heat"
    cbs_version = "cbs_version"
    ota = "ota"
    # Execute status
    execute = "execute"
    # Controls (not reported by device, for HA entity mapping)
    power = "power"
    screen_luminance = "screen_luminance"
    volume = "volume"


# Attributes that can be directly set on MessageSet (same name on device and message)
_SETTABLE_ATTRS: frozenset[DeviceAttributes] = frozenset(
    {
        DeviceAttributes.power,
        DeviceAttributes.child_lock,
        DeviceAttributes.furnace_light,
        DeviceAttributes.hot_wind,
        DeviceAttributes.door,
        DeviceAttributes.screen_luminance,
        DeviceAttributes.volume,
        DeviceAttributes.ramadan,
        DeviceAttributes.work_mode,
        DeviceAttributes.fire_power,
        DeviceAttributes.temperature,
        DeviceAttributes.temperature_above,
        DeviceAttributes.temperature_underside,
        DeviceAttributes.probe_temperature,
        DeviceAttributes.steam_quantity,
        DeviceAttributes.weight,
        DeviceAttributes.people_number,
        DeviceAttributes.turntable,
        DeviceAttributes.pre_heat,
        DeviceAttributes.hour_set,
        DeviceAttributes.minute_set,
        DeviceAttributes.second_set,
    },
)

# Work-mode-related attributes that need current work_mode context to serialize
# correctly via workModeControl instead of an empty setControl body.
_WORK_MODE_SETTABLE_ATTRS: frozenset[DeviceAttributes] = frozenset(
    {
        DeviceAttributes.work_mode,
        DeviceAttributes.fire_power,
        DeviceAttributes.temperature,
        DeviceAttributes.temperature_above,
        DeviceAttributes.temperature_underside,
        DeviceAttributes.probe_temperature,
        DeviceAttributes.steam_quantity,
        DeviceAttributes.weight,
        DeviceAttributes.people_number,
        DeviceAttributes.turntable,
        DeviceAttributes.pre_heat,
        DeviceAttributes.hot_wind,
    },
)

# Numeric attributes serialized with bit-shift / mask operations on MessageSet.
# Callers (e.g. Home Assistant number entities) may pass floats, so coerce to int
# before assignment to avoid a TypeError during serialization.
_INT_ATTRS: frozenset[DeviceAttributes] = frozenset(
    {
        DeviceAttributes.temperature,
        DeviceAttributes.temperature_above,
        DeviceAttributes.temperature_underside,
        DeviceAttributes.probe_temperature,
        DeviceAttributes.steam_quantity,
        DeviceAttributes.weight,
        DeviceAttributes.people_number,
        DeviceAttributes.screen_luminance,
        DeviceAttributes.volume,
        DeviceAttributes.hour_set,
        DeviceAttributes.minute_set,
        DeviceAttributes.second_set,
    },
)


class MideaBFDevice(MideaDevice):
    """Midea BF device."""

    def __init__(
        self,
        *,
        customize: str,  # noqa: ARG002
        **kwargs: Unpack[MideaDeviceInitKwargs],
    ) -> None:
        """Initialize Midea BF device."""
        super().__init__(
            device_type=DeviceType.BF,
            **kwargs,
            attributes=dict.fromkeys(DeviceAttributes, None),
        )

    def build_query(self) -> list[MessageQuery]:
        """Midea BF device build query."""
        return [MessageQuery(self._message_protocol_version)]

    def process_message(self, msg: bytes) -> dict[str, Any]:
        """Midea BF device process message."""
        message = MessageBFResponse(msg)
        _LOGGER.debug("[%s] Received: %s", self.device_id, message)
        # message layer already resolves work_status into a string name
        # (see MessageBFBody._parse_status_and_power), so no translator needed.
        new_status: dict[str, Any] = {}
        for status in self._attributes:
            if hasattr(message, str(status)):
                value = getattr(message, str(status))
                self._attributes[status] = value
                new_status[str(status)] = value
        return new_status

    def make_message_set(self) -> MessageSet:
        """Create a MessageSet pre-populated with current work-mode attributes.

        Ensures that adjusting a single work-mode parameter (e.g. fire_power)
        carries the active work_mode so the message routes to workModeControl
        rather than producing an empty setControl command.
        """
        message = MessageSet(self._message_protocol_version)
        message.work_mode = self._attributes[DeviceAttributes.work_mode]
        # Carry the configured cook time so a work-mode resend keeps it instead
        # of defaulting to zero (see _build_work_mode_control).
        message.work_hour = self._attributes[DeviceAttributes.hour_set]
        message.work_minute = self._attributes[DeviceAttributes.minute_set]
        message.work_second = self._attributes[DeviceAttributes.second_set]
        message.fire_power = self._attributes[DeviceAttributes.fire_power]
        message.temperature = self._attributes[DeviceAttributes.temperature]
        message.temperature_above = self._attributes[DeviceAttributes.temperature_above]
        message.temperature_underside = self._attributes[
            DeviceAttributes.temperature_underside
        ]
        message.probe_temperature = self._attributes[DeviceAttributes.probe_temperature]
        message.steam_quantity = self._attributes[DeviceAttributes.steam_quantity]
        message.weight = self._attributes[DeviceAttributes.weight]
        message.people_number = self._attributes[DeviceAttributes.people_number]
        message.turntable = self._attributes[DeviceAttributes.turntable]
        message.pre_heat = self._attributes[DeviceAttributes.pre_heat]
        message.hot_wind = self._attributes[DeviceAttributes.hot_wind]
        return message

    def set_attribute(self, attr: str, value: bool | float | str) -> None:
        """Midea BF device set attribute."""
        # status on device maps to work_status on message
        if attr == DeviceAttributes.status:
            if not isinstance(value, str):
                _LOGGER.warning(
                    "[%s] Invalid status value: %r (expected str)",
                    self.device_id,
                    value,
                )
                return
            # Reject names not in WorkStatus so an unknown status is not silently
            # serialized as the 0xFF no-change sentinel.
            if value not in WorkStatus.__members__:
                _LOGGER.warning(
                    "[%s] Unsupported status value: %s",
                    self.device_id,
                    value,
                )
                return
            message = MessageSet(self._message_protocol_version)
            message.work_status = value
            self.build_send(message)
            return

        if attr not in _SETTABLE_ATTRS:
            _LOGGER.warning("[%s] Unsupported attribute: %s", self.device_id, attr)
            return

        # Reject work_mode names not in the mapping so they are not silently sent
        # as a no-op (0xFF) command with no state change.
        if attr == DeviceAttributes.work_mode and value not in WORK_MODE_MAP:
            _LOGGER.warning(
                "[%s] Unsupported work_mode value: %s",
                self.device_id,
                value,
            )
            return

        # Same for fire_power: an unknown name maps to the 0xFF no-change sentinel
        # in MessageSet, which would silently re-issue the program unchanged.
        if attr == DeviceAttributes.fire_power and value not in FirePower.__members__:
            _LOGGER.warning(
                "[%s] Unsupported fire_power value: %s",
                self.device_id,
                value,
            )
            return

        # Work-mode-related attributes need the current work_mode context so the
        # MessageSet routes to workModeControl instead of an empty setControl.
        if attr in _WORK_MODE_SETTABLE_ATTRS:
            message = self.make_message_set()
        else:
            message = MessageSet(self._message_protocol_version)
        # Coerce numeric fields to int: MessageSet serializes them with >> and &,
        # which raise TypeError on float input from callers like HA number entities.
        if attr in _INT_ATTRS and isinstance(value, (int, float)):
            value = int(value)
        # A caller-set people_number must clear weight, otherwise the shared
        # parse (weight always set) makes _build_work_mode_control prefer weight.
        if attr == DeviceAttributes.people_number:
            message.weight = None
        setattr(message, attr, value)
        self.build_send(message)


class MideaAppliance(MideaBFDevice):
    """Midea BF appliance."""
