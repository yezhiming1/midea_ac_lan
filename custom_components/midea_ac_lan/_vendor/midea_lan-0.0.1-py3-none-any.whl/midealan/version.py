"""Midea Lan Version."""

__version__ = "0.0.1"
